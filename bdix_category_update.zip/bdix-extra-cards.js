/* BDIX category cards extension. No existing channels or settings are changed. */
(function(){
  'use strict';
  const categories = [
    {name:'BIG BOSS', icon:'📺', description:'6 language channels', key:'BIG BOSS'},
    {name:'SPORTS', icon:'🏟️', description:'37 playlist entries', key:'SPORTS'}
  ];
  function mount(selector){
    const host=document.querySelector(selector);
    if(!host) return;
    for(const category of categories){
      if(host.querySelector('[data-bdix-extra="'+category.key+'"]')) continue;
      const button=document.createElement('button');
      button.type='button';button.className='bdix-extra-category-card';
      button.dataset.bdixExtra=category.key;
      button.setAttribute('aria-label','Open '+category.name+' category');
      const symbol=document.createElement('span');symbol.className='bdix-extra-symbol';symbol.textContent=category.icon;
      const title=document.createElement('strong');title.textContent=category.name;
      const description=document.createElement('small');description.textContent=category.description;
      button.append(symbol,title,description);
      button.addEventListener('click',()=>document.dispatchEvent(new CustomEvent('bdix:category-selected',{detail:{category:category.key}})));
      host.appendChild(button);
    }
  }
  window.BDIXExtraCategories={categories,mount};
  document.addEventListener('DOMContentLoaded',()=>{
    mount('[data-bdix-viewer-categories]');
    mount('[data-bdix-admin-categories]');
  });
})();
