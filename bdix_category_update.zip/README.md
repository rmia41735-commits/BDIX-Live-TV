# BDIX Live TV category integration package

Inspected uploaded M3U files: 6 BIG BOSS entries and 37 SPORTS entries.

## Integration

1. Copy `bdix-extra-cards.js` and `bdix-extra-cards.css` into the app's public assets.
2. Include CSS and JS in the HTML (JS with `defer`).
3. Add `data-bdix-viewer-categories` to the viewer card grid and `data-bdix-admin-categories` to the admin category grid. Or call `BDIXExtraCategories.mount(selector)` with the app's existing grid selectors.
4. Handle the `bdix:category-selected` event using the application's existing category filtering/navigation code. Do not duplicate existing category cards.
5. Import `channels-metadata.json` for display metadata only. Stream URLs are intentionally null until authorized, browser-compatible sources are supplied.
6. Test viewer, admin, mobile layout and player behavior before deploying.

This is an integration patch, not a deployed update. The current Vercel deployment was not modified. The uploaded GitHub workflows require `scripts/BiggBoss.py` and `scripts/Sport_S1.py`, which were not supplied. Do not publish access cookies, bearer tokens, or other private playback credentials.
