BDIX TV remote player review package.
Contains modified player.js and player.css plus original player.html.
Tested: JavaScript syntax and static controls. NOT tested on physical TVs or with licensed streams.
Remote: D-pad focus navigation, Enter/OK, Back/Escape, media play/pause, rewind/fast-forward.
This is NOT deployed. Existing Gmax gateway/proxy references must be replaced with authorized BDIX API integration before production use.
Do not publish third-party cookies or DRM keys.
