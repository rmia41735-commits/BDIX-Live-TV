BDIX PLAY TV — Mobile promotion update

Scope: replacement of two existing production assets, not a complete website.
Back up the current working source before editing. The linked GitHub repository
was missing these files and may not contain the complete deployed site. Do not
deploy this ZIP or the incomplete linked repository as a standalone website.

1. In the complete production source, replace dist/admin-controls.js and
   dist/admin-controls.css (Vercel lists these under src/dist/).
2. In the existing dist/index.html, change both admin-controls asset query
   strings from ?v=1 to ?v=2 to invalidate old cached references.
3. Commit the changes to a branch of the correct complete repository. Deploy a
   preview with the existing Vercel configuration and API routes unchanged.
4. In Admin > API & settings, enter a name, a real HTTPS landing page or phone,
   and a direct HTTPS image URL. Do not use an AdSense JavaScript URL as a link.
   Enable Show on mobile. Disable auto-close for the initial test. Publish.
5. In a separate signed-in viewer session on a phone/tablet, wait up to 15 seconds.
   Check that the card appears, closes, and does not repeatedly reopen. Test
   disabling/re-enabling, republishing a changed card, and five-second auto-close.
6. Confirm existing channels, authentication and settings still work before
   promoting the preview to production. Roll back if regression occurs.

This update preserves the existing settings API and viewer authentication.
It is a custom promotion card, not a Google AdSense integration.
JavaScript syntax checked locally; authenticated end-to-end testing is pending.
